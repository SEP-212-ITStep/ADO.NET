﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Game_Dll
{
    public class GameContext : DbContext
    {
        public DbSet<Model> Games { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            builder.UseSqlServer("Server=DESKTOP-6O1ENUJ;Database=GamesInfo;Trusted_Connection=true;Encrypt=false");
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Model>().HasData(new List<Model>()
            {
                new Model()
                {
                   Id = 1,
                   Game_Name = "God of war",
                   Developer_Name = "Santa Monica Studio",
                   Game_Style = "Action",
                   Game_Mode = "God killer",
                   //Sales = 10000000,
                   Publishing_Year = 2018
                }
            });
        }
    }
}
